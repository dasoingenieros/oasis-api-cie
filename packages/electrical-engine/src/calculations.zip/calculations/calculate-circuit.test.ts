/**
 * Tests: calculateCircuit() — función principal del motor
 *
 * Cobertura:
 *   - Resultado completo con todos los campos
 *   - Orquestación correcta
 *   - EngineError en fallos
 *   - isValid y isCompliant
 */

import { calculateCircuit } from "./calculate-circuit";
import { EngineError } from "../types";
import type { CircuitInput } from "../types";

function makeCircuitInput(overrides: Partial<CircuitInput> = {}): CircuitInput {
  return {
    id: "circ-1",
    label: "C1 Alumbrado",
    code: "C1",
    phaseSystem: "single",
    loadPowerW: 2300,
    powerFactor: 1.0,
    simultaneityFactor: 1.0,
    loadFactor: 1.0,
    conductorMaterial: "Cu",
    insulationType: "PVC",
    installationMethod: "B1",
    lengthM: 10,
    ambientTempC: 40,
    groupingCircuits: 1,
    ...overrides,
  };
}

// ════════════════════════════════════════════════════════════════════════════
// Estructura del resultado
// ════════════════════════════════════════════════════════════════════════════

describe("calculateCircuit", () => {
  it("devuelve CircuitResult completo con todos los campos requeridos", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);

    expect(result.id).toBe("circ-1");
    expect(typeof result.nominalCurrentA).toBe("number");
    expect(typeof result.admissibleCurrentA).toBe("number");
    expect(typeof result.sectionMm2).toBe("number");
    expect(result.sectionMm2).toBeGreaterThan(0);
    expect(["thermal", "voltage_drop", "minimum_itcbt25"]).toContain(result.sectionCriteria);
    expect(typeof result.voltageDropPct).toBe("number");
    expect(typeof result.accumulatedCdtPct).toBe("number");
    expect(typeof result.cdtLimitPct).toBe("number");
    expect(typeof result.cdtCompliant).toBe("boolean");
    expect(result.breakerRatingA).toBeDefined();
    expect(result.breakerCurve).toMatch(/^[BCD]$/);
    expect([30, 300, null]).toContain(result.rcdSensitivityMa);
    expect(typeof result.isCompliant).toBe("boolean");
    expect(typeof result.isValid).toBe("boolean");
    expect(Array.isArray(result.warnings)).toBe(true);
    expect(Array.isArray(result.errors)).toBe(true);
    expect(result.justification).toBeDefined();
    expect(result.justification.steps.length).toBeGreaterThan(0);
    expect(result.tubeDiameterMm).toBeDefined();
    expect(result.tubeDiameterMm).toBeGreaterThanOrEqual(16);
  });

  it("isValid es true cuando el circuito cumple todos los criterios", () => {
    const input = makeCircuitInput({ loadPowerW: 2300, lengthM: 5 });
    const result = calculateCircuit(input);
    expect(result.isValid).toBe(true);
    expect(result.isCompliant).toBe(result.isValid);
  });

  it("incluye sección seleccionada y criterio determinante", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);
    expect([1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300]).toContain(result.sectionMm2);
    expect(result.sectionCriteria).toBeDefined();
  });

  it("incluye intensidad nominal correcta", () => {
    const input = makeCircuitInput({ loadPowerW: 2300 });
    const result = calculateCircuit(input);
    expect(result.nominalCurrentA).toBeCloseTo(10, 1);
  });

  it("incluye PIA recomendado (breaker)", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);
    expect([6, 10, 13, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250]).toContain(result.breakerRatingA);
    expect(result.breakerCurve).toMatch(/^[BCD]$/);
  });

  it("incluye diferencial recomendado (RCD)", () => {
    const input = makeCircuitInput({ code: "C1" });
    const result = calculateCircuit(input);
    expect(result.rcdSensitivityMa).toBe(30);

    const inputC11 = makeCircuitInput({ code: "C11" });
    const resultC11 = calculateCircuit(inputC11);
    expect(resultC11.rcdSensitivityMa).toBe(300);
  });

  it("incluye diámetro de tubo", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);
    expect(result.tubeDiameterMm).toBeDefined();
    expect([16, 20, 25, 32, 40, 50, 63]).toContain(result.tubeDiameterMm);
  });

  it("incluye pasos de justificación no vacíos", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);
    expect(result.justification.steps.length).toBeGreaterThan(0);
    for (const step of result.justification.steps) {
      expect(step.order).toBeDefined();
      expect(step.description?.length).toBeGreaterThan(0);
      expect(step.result).toBeDefined();
    }
  });

  it("incluye caída de tensión y cumplimiento", () => {
    const input = makeCircuitInput();
    const result = calculateCircuit(input);
    expect(result.voltageDropPct).toBeGreaterThanOrEqual(0);
    expect(result.accumulatedCdtPct).toBeGreaterThanOrEqual(0);
    expect(result.cdtLimitPct).toBeGreaterThan(0);
    expect(typeof result.cdtCompliant).toBe("boolean");
  });
});

// ════════════════════════════════════════════════════════════════════════════
// EngineError
// ════════════════════════════════════════════════════════════════════════════

describe("calculateCircuit — EngineError", () => {
  it("lanza EngineError para potencia inválida (0)", () => {
    const input = makeCircuitInput({ loadPowerW: 0 });
    expect(() => calculateCircuit(input)).toThrow(EngineError);
  });

  it("lanza EngineError para potencia negativa", () => {
    const input = makeCircuitInput({ loadPowerW: -100 });
    expect(() => calculateCircuit(input)).toThrow(EngineError);
  });

  it("lanza EngineError para cosφ inválido", () => {
    const input = makeCircuitInput({ powerFactor: 0 });
    expect(() => calculateCircuit(input)).toThrow(EngineError);
  });

  it("el EngineError incluye circuitId", () => {
    const input = makeCircuitInput({
      id: "circuito-test-123",
      loadPowerW: 0,
    });
    try {
      calculateCircuit(input);
      fail("Debe lanzar EngineError");
    } catch (e) {
      expect(e).toBeInstanceOf(EngineError);
      expect((e as EngineError).circuitId).toBe("circuito-test-123");
      expect((e as EngineError).code).toBeDefined();
    }
  });
});

// ════════════════════════════════════════════════════════════════════════════
// Circuitos variados
// ════════════════════════════════════════════════════════════════════════════

describe("calculateCircuit — circuitos variados", () => {
  it("C1 alumbrado: sección 1.5mm², PIA 10A", () => {
    const input = makeCircuitInput({ code: "C1", loadPowerW: 2300 });
    const result = calculateCircuit(input);
    expect(result.sectionMm2).toBe(1.5);
    expect(result.breakerRatingA).toBe(10);
  });

  it("C3 cocina: sección 6mm², PIA 25A", () => {
    const input = makeCircuitInput({
      code: "C3",
      loadPowerW: 5400,
      lengthM: 5,
    });
    const result = calculateCircuit(input);
    expect(result.sectionMm2).toBe(6);
    expect(result.breakerRatingA).toBe(25);
  });

  it("trifásico: calcula correctamente", () => {
    const input = makeCircuitInput({
      phaseSystem: "three",
      loadPowerW: 18000,
      powerFactor: 0.9,
      lengthM: 15,
    });
    const result = calculateCircuit(input);
    expect(result.nominalCurrentA).toBeCloseTo(28.87, 0);
  });

  it("circuito largo con CdT excedida: isValid puede ser false", () => {
    const input = makeCircuitInput({
      code: "C2",
      loadPowerW: 3450,
      lengthM: 150,
    });
    const result = calculateCircuit(input);
    // Con 150m la CdT puede exceder el límite
    expect(typeof result.isValid).toBe("boolean");
    expect(result.errors).toBeDefined();
    if (!result.cdtCompliant) {
      expect(result.errors.some((e) => e.includes("Caída de tensión"))).toBe(true);
    }
  });

  it("CUSTOM: usa curva C por defecto", () => {
    const input = makeCircuitInput({
      code: "CUSTOM",
      loadPowerW: 3500,
    });
    const result = calculateCircuit(input);
    expect(result.breakerCurve).toBe("C");
    expect(result.sectionMm2).toBeGreaterThanOrEqual(2.5);
  });
});
